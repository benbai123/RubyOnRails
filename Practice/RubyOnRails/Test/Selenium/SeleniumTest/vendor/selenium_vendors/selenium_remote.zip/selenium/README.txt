basically use startup.bat for 32 bit Windows and
startup64.bat for 64 bit Windows
but if you find send_keys works slow in IE
then you can try another one

use startOpera.bat for opera driver with port 5555.